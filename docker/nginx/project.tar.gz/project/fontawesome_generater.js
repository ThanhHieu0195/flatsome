const fs = require("fs");
const d = fs.readFileSync(
  "/srv/pwordpress/datvietweb/wp-content/themes/flatsome-child/fontawesome-pro-5.15.3-web/css/all.css",
  "utf-8"
);

const html = d
  .match(/\.fa-([\w\-]+)/g)
  .map(
    (i) =>
      `<li>${i}<i style="font-size: 50px" class="fa ${i.replace(
        ".",
        ""
      )}"></i></li>`
  )
  .join("");

fs.writeFileSync(
  "fontawesome.html",
  `
<ul>
${html}
</ul>
<link
  rel="stylesheet"
  href="/wp-content/themes/flatsome-child/fontawesome-pro-5.15.3-web/css/all.css?ver=5.8.1"
/>

`
);
